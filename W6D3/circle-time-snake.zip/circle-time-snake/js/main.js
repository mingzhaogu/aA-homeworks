/* globals $ */

var View = require("./view");

$(function () {
  var $easel = $("#easel");
  new View($easel);
});
